sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("incidentapp07.myapplication07.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map